package com.example.buttons;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Main extends Activity
{
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        final Button button1 = (Button) findViewById(R.id.image_button_1);
        final View button2 = findViewById(R.id.image_button_2);
        final View button3 = findViewById(R.id.image_button_3);

        button1.setOnClickListener(new View.OnClickListener() {
        	@Override
        	public void onClick(View v) {
        		toastButton(1);
        	}
        });
        button2.setOnClickListener(new View.OnClickListener() {
        	@Override
        	public void onClick(View v) {
        		toastButton(2);
        	}
        });
        button3.setOnClickListener(new View.OnClickListener() {
        	@Override
        	public void onClick(View v) {
        		toastButton(3);
        	}
        });
    }

    public void toastButton(int index) {
    	Toast.makeText(this, "Button " + index + " pressed", Toast.LENGTH_SHORT).show();
    }
}
